# Code snap 📸

<p>code snap plugin for acode</p>
<h3>
 Latest version 1.0.3
</h3>

-> Added window Background <br />
-> Added Code Formatter <br />
-> Change Default Theme <br />
-> Bug fixes <br />

![Code_snap_286 1](https://github.com/mayank0274/acode-plugin-codesnap/assets/113236810/656d684f-46e1-40f6-b3a9-413b70009d46)

A simple plugin for acode editor to take code snaps

# Usage

![ezgif com-video-to-gif](https://github.com/mayank0274/acode-plugin-codesnap/assets/113236810/c8b094c4-fd6c-4b1d-8840-e576eb8ebc6f)
